from django.apps import AppConfig


class UrlConfig(AppConfig):
    name = 'url'
